<footer class="py-5">
    <div class="container">
        <div class="row align-items-center justify-content-xl-between">
            <div class="col-xl-12">
                <div class="copyright text-center text-muted">
                    &copy; {{ now()->year }} <a href="http://apak.it" class="font-weight-bold ml-1" target="_blank">apak.it</a>
                </div>
            </div>
            
        </div>
    </div>
</div> 